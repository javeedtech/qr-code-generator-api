# QR Code Generator API Documentation

## Overview
Complete API documentation for the QR Code Generator service, providing comprehensive endpoints for creating customizable QR codes with advanced styling options.

## Base URL
```
https://site--qr-code-generator-api--lrw6bbnkrwj5.code.run/
```

## API Endpoints

### Health Check
```http
GET /health
```
Returns service status and health information.

### QR Code Generation Endpoints

#### URL QR Code
```http
POST /api/v1/qr/url
```

#### Text QR Code  
```http
POST /api/v1/qr/text
```

#### Email QR Code
```http
POST /api/v1/qr/email
```

#### Phone QR Code
```http
POST /api/v1/qr/phone
```

#### SMS QR Code
```http
POST /api/v1/qr/sms
```

#### vCard QR Code
```http
POST /api/v1/qr/vcard
```

#### WiFi QR Code
```http
POST /api/v1/qr/wifi
```

#### Location QR Code
```http
POST /api/v1/qr/location
```

## Request Format
All endpoints accept JSON requests with the following structure:

```json
{
  "data": "content_data",
  "options": {
    "size": 10,
    "format": "PNG",
    "foreground_color": "#000000",
    "background_color": "#FFFFFF",
    "module_drawer": "square",
    "error_correction": "M"
  }
}
```

## Response Format
```json
{
  "success": true,
  "qr_code": "base64_encoded_image",
  "format": "PNG",
  "content_type": "image/png"
}
```

## Customization Options

### Size
- Range: 1-20
- Default: 10

### Format
- PNG (default)
- JPEG  
- SVG
- PDF

### Module Styles
- square (default)
- rounded
- circle

### Error Correction
- L (~7% recovery)
- M (~15% recovery) - default
- Q (~25% recovery)
- H (~30% recovery)

## Rate Limits
- Free tier: 1 request per second
- Paid tiers: Up to 10 requests per second

## Error Handling
The API returns appropriate HTTP status codes and error messages for invalid requests or server errors.