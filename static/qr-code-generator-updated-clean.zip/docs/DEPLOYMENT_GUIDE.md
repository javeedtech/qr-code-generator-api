# Deployment Guide

## Overview
This guide covers deployment options for the QR Code Generator API across different platforms.

## Current Live Deployment
- **Platform**: Northflank
- **URL**: https://site--qr-code-generator-api--lrw6bbnkrwj5.code.run/
- **Status**: Live and operational

## Deployment Platforms

### 1. Northflank (Current)
- **Configuration**: Uses `.python-version` file
- **Runtime**: Python 3.11
- **Process**: Gunicorn with auto-reload
- **Features**: Auto-scaling, SSL, monitoring

### 2. Render (Alternative)
- **Configuration**: Uses `render.yaml` and `runtime.txt`
- **Keep-alive**: Automatic pinging to prevent free tier sleeping
- **Features**: Free tier available, easy GitHub integration

### 3. Railway (Alternative)
- **Configuration**: Automatic Python detection
- **Features**: Simple deployment, good for prototyping

## Required Files for Deployment

### Core Application
- `app.py` - Main Flask application
- `qr_generator.py` - QR code generation engine
- `main.py` - Application entry point
- `requirements.txt` - Python dependencies

### Configuration
- `Procfile` - Process configuration
- `.python-version` - Python version specification (Northflank)
- `runtime.txt` - Python version (Render/Railway)

### Frontend
- `templates/` - HTML templates
- `static/` - CSS, JavaScript, and other assets

### Documentation
- `README.md` - Project overview
- `docs/` - Additional documentation

## Environment Variables
- `SESSION_SECRET` - Flask session security key
- `PORT` - Application port (auto-configured on most platforms)

## Health Monitoring
- Endpoint: `/health`
- Returns: Service status and timestamp
- Used for: Keep-alive pings and monitoring

## Scaling Considerations
- Stateless design allows horizontal scaling
- Image generation is CPU-intensive
- Consider CDN for static assets in production