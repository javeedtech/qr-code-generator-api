# QR Code Generator API Pro - Documentation

## Overview

The QR Code Generator API Pro is a comprehensive solution for generating high-quality QR codes with advanced customization options. Perfect for mobile apps, websites, marketing campaigns, and any application requiring QR code generation.

## Key Features

### 🎯 **8 QR Code Types Supported**
- **URL**: Website links and deep links
- **Text**: Plain text content  
- **Email**: Pre-filled email composition
- **Phone**: Direct phone calls
- **SMS**: Pre-filled text messages
- **vCard**: Contact information cards
- **WiFi**: Network connection sharing
- **Location**: GPS coordinates and maps

### 🎨 **Advanced Customization**
- **Colors**: Custom foreground and background colors (hex format)
- **Shapes**: Square, rounded, or circle module styles
- **Sizes**: Adjustable from 1-40 module size
- **Error Correction**: L (7%), M (15%), Q (25%), H (30%) levels
- **Formats**: PNG, SVG, PDF output options
- **Borders**: Configurable border spacing (0-20 pixels)

### ⚡ **High Performance**
- Fast generation (typically <200ms response time)
- Base64 encoded output for immediate use
- Optimized image compression
- Built-in rate limiting for fair usage

## Quick Start

### Base URL
```
https://qr-code-api-pro.onrender.com
```

### Authentication
Include your RapidAPI key in the request headers:
```
X-RapidAPI-Key: YOUR_RAPIDAPI_KEY
X-RapidAPI-Host: qr-code-api-pro.onrender.com
```

### Basic URL QR Code
```bash
curl -X POST "https://qr-code-api-pro.onrender.com/api/v1/qr/url" \
  -H "Content-Type: application/json" \
  -H "X-RapidAPI-Key: YOUR_KEY" \
  -d '{
    "url": "https://rapidapi.com",
    "options": {
      "foreground_color": "#0066cc",
      "background_color": "#ffffff",
      "size": 10
    }
  }'
```

## API Endpoints

### 1. Health Check
**GET** `/health`

Check API status and uptime.

**Response:**
```json
{
  "service": "QR Code Generator API",
  "status": "healthy",
  "timestamp": "2025-08-11T15:15:39.380599",
  "version": "1.0.0"
}
```

### 2. URL QR Code
**POST** `/api/v1/qr/url`

Generate QR codes for website URLs and deep links.

**Request Body:**
```json
{
  "url": "https://rapidapi.com",
  "options": {
    "foreground_color": "#0066cc",
    "background_color": "#ffffff",
    "size": 10,
    "module_drawer": "square",
    "error_correction": "M",
    "format": "PNG",
    "border": 4
  }
}
```

### 3. Text QR Code
**POST** `/api/v1/qr/text`

Generate QR codes containing plain text.

**Request Body:**
```json
{
  "text": "Hello RapidAPI!",
  "options": {
    "foreground_color": "#ff6600",
    "module_drawer": "rounded"
  }
}
```

### 4. Email QR Code
**POST** `/api/v1/qr/email`

Generate QR codes that open email clients with pre-filled content.

**Request Body:**
```json
{
  "email": "contact@example.com",
  "subject": "Hello from QR Code",
  "body": "This email was generated from a QR code!",
  "options": {
    "foreground_color": "#009900"
  }
}
```

### 5. Phone QR Code
**POST** `/api/v1/qr/phone`

Generate QR codes that initiate phone calls.

**Request Body:**
```json
{
  "phone": "+1234567890",
  "options": {
    "error_correction": "H"
  }
}
```

### 6. SMS QR Code
**POST** `/api/v1/qr/sms`

Generate QR codes that open SMS apps with pre-filled messages.

**Request Body:**
```json
{
  "phone": "+1234567890",
  "message": "Hello from QR Code!",
  "options": {
    "module_drawer": "circle"
  }
}
```

### 7. vCard QR Code
**POST** `/api/v1/qr/vcard`

Generate QR codes containing contact information.

**Request Body:**
```json
{
  "name": "John Doe",
  "phone": "+1234567890",
  "email": "john@example.com",
  "organization": "RapidAPI Inc.",
  "title": "Software Developer",
  "url": "https://rapidapi.com",
  "options": {
    "foreground_color": "#990066"
  }
}
```

### 8. WiFi QR Code
**POST** `/api/v1/qr/wifi`

Generate QR codes for WiFi network connection.

**Request Body:**
```json
{
  "ssid": "MyWiFiNetwork",
  "password": "securepassword123",
  "security": "WPA",
  "hidden": false,
  "options": {
    "size": 12
  }
}
```

### 9. Location QR Code
**POST** `/api/v1/qr/location`

Generate QR codes containing GPS coordinates.

**Request Body:**
```json
{
  "latitude": 37.7749,
  "longitude": -122.4194,
  "options": {
    "format": "PNG",
    "border": 2
  }
}
```

## Response Format

### Success Response
```json
{
  "success": true,
  "data": {
    "qr_code": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAA...",
    "content": "https://rapidapi.com",
    "format": "PNG",
    "options": {
      "foreground_color": "#0066cc",
      "background_color": "#ffffff",
      "size": 10,
      "module_drawer": "square",
      "error_correction": "M",
      "format": "PNG",
      "border": 4
    }
  }
}
```

### Error Response
```json
{
  "success": false,
  "error": "URL is required"
}
```

## Customization Options

### Colors
- **foreground_color**: QR code pattern color (hex format: #000000)
- **background_color**: QR code background color (hex format: #ffffff)

### Module Shapes
- **square**: Standard square modules (default)
- **rounded**: Rounded corner modules for modern look
- **circle**: Circular modules for unique style

### Error Correction Levels
- **L**: Low (7% error correction) - Smallest size
- **M**: Medium (15% error correction) - Balanced (default)
- **Q**: Quartile (25% error correction) - Good for damaged codes
- **H**: High (30% error correction) - Best reliability

### Output Formats
- **PNG**: Raster image format (default) - Best for web/mobile
- **SVG**: Vector format - Scalable, smaller file size
- **PDF**: Document format - Best for printing

### Size and Border
- **size**: Module size (1-40) - Controls overall QR code size
- **border**: Border width (0-20) - White space around QR code

## Code Examples

### JavaScript (Fetch)
```javascript
const response = await fetch('https://qr-code-api-pro.onrender.com/api/v1/qr/url', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'X-RapidAPI-Key': 'YOUR_RAPIDAPI_KEY',
    'X-RapidAPI-Host': 'qr-code-api-pro.onrender.com'
  },
  body: JSON.stringify({
    url: 'https://rapidapi.com',
    options: {
      foreground_color: '#0066cc',
      background_color: '#ffffff',
      size: 10
    }
  })
});

const data = await response.json();
console.log(data.data.qr_code); // Base64 encoded QR code
```

### Python (Requests)
```python
import requests
import json

url = "https://qr-code-api-pro.onrender.com/api/v1/qr/url"
headers = {
    "Content-Type": "application/json",
    "X-RapidAPI-Key": "YOUR_RAPIDAPI_KEY",
    "X-RapidAPI-Host": "qr-code-api-pro.onrender.com"
}

payload = {
    "url": "https://rapidapi.com",
    "options": {
        "foreground_color": "#0066cc",
        "background_color": "#ffffff",
        "size": 10
    }
}

response = requests.post(url, headers=headers, data=json.dumps(payload))
data = response.json()
print(data["data"]["qr_code"])  # Base64 encoded QR code
```

### PHP (cURL)
```php
<?php
$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://qr-code-api-pro.onrender.com/api/v1/qr/url',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS => json_encode(array(
    'url' => 'https://rapidapi.com',
    'options' => array(
      'foreground_color' => '#0066cc',
      'background_color' => '#ffffff',
      'size' => 10
    )
  )),
  CURLOPT_HTTPHEADER => array(
    'Content-Type: application/json',
    'X-RapidAPI-Key: YOUR_RAPIDAPI_KEY',
    'X-RapidAPI-Host: qr-code-api-pro.onrender.com'
  ),
));

$response = curl_exec($curl);
curl_close($curl);

$data = json_decode($response, true);
echo $data['data']['qr_code']; // Base64 encoded QR code
?>
```

## Use Cases

### Mobile Apps
- User profile sharing
- App download links
- Deep linking to specific app screens
- WiFi sharing for guests

### E-commerce
- Product information and reviews
- Coupon codes and discounts
- Payment links and invoices
- Customer support contact

### Marketing
- Campaign tracking URLs
- Social media links
- Event registration
- Business card replacement

### Real Estate
- Property listing details
- Virtual tour links
- Contact information
- Location coordinates

## Error Handling

The API returns appropriate HTTP status codes:

- **200**: Success - QR code generated successfully
- **400**: Bad Request - Invalid input parameters
- **429**: Too Many Requests - Rate limit exceeded
- **500**: Internal Server Error - Server-side issue

Always check the `success` field in the response to determine if the request was successful.

## Rate Limits

The API includes built-in rate limiting to ensure fair usage:

- **Free Tier**: 500 requests/month, 1 request/second
- **Starter Tier**: 2,000 requests/month, 2 requests/second
- **Basic Tier**: 5,000 requests/month, 3 requests/second
- **Pro Tier**: 15,000 requests/month, 5 requests/second
- **Ultra Tier**: 100,000 requests/month, 10 requests/second

Rate limit information is included in response headers:
- `X-RateLimit-Limit`: Maximum requests allowed
- `X-RateLimit-Remaining`: Requests remaining in current period
- `X-RateLimit-Reset`: Timestamp when rate limit resets

## Best Practices

1. **Cache Results**: Store generated QR codes to avoid regenerating identical codes
2. **Error Handling**: Always check the `success` field before using the QR code
3. **Optimal Settings**: Use error correction level M for most applications
4. **Size Guidelines**: Size 8-12 works well for most mobile scanning scenarios
5. **Color Contrast**: Ensure sufficient contrast between foreground and background
6. **Testing**: Test QR codes with multiple scanning apps before production use

## Support

- **Demo Interface**: https://qr-code-api-pro.onrender.com
- **API Documentation**: https://qr-code-api-pro.onrender.com/docs
- **Health Check**: https://qr-code-api-pro.onrender.com/health

For technical support and questions, contact the RapidAPI marketplace support team.