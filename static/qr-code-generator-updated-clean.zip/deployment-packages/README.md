# Deployment Packages

This directory contains pre-configured deployment packages for different platforms.

## Available Packages

### northflank/
Complete deployment package for Northflank platform:
- Uses `.python-version` file for Python 3.11
- Optimized Procfile configuration
- Northflank-specific branding and templates

### render/
Deployment package for Render platform:
- Uses `runtime.txt` for Python version
- Includes keep-alive functionality
- render.yaml configuration

### railway/
Deployment package for Railway platform:
- Minimal configuration (auto-detection)
- Simple deployment process

## Usage
1. Choose the appropriate platform directory
2. Copy files to your deployment repository
3. Follow the platform-specific deployment guide
4. Configure environment variables as needed

## Live Deployment
Current production deployment is running on Northflank:
https://site--qr-code-generator-api--lrw6bbnkrwj5.code.run/

## Download Routes
The main application provides download routes for these packages:
- `/download-northflank` - Northflank deployment package
- `/download` - General deployment package