#!/usr/bin/env python3
"""
Multi-deployment monitoring script for QR Code API
Monitors both Render and Northflank deployments
"""

import requests
import time
from datetime import datetime

# Your deployment URLs
DEPLOYMENTS = {
    "Render (RapidAPI)": "https://qr-code-api-pro.onrender.com",
    "Northflank (New Markets)": "https://your-app.northflank.app"  # Update after deployment
}

def check_deployment(name, url):
    """Check if a deployment is healthy"""
    try:
        # Check health endpoint
        health_response = requests.get(f"{url}/health", timeout=10)
        
        if health_response.status_code == 200:
            health_data = health_response.json()
            print(f"✅ {name}: Healthy - {health_data.get('service', 'Unknown')}")
            
            # Test a QR endpoint
            test_response = requests.post(
                f"{url}/api/v1/qr/url",
                json={"url": "https://test.com"},
                headers={"Content-Type": "application/json"},
                timeout=10
            )
            
            if test_response.status_code == 200:
                print(f"   API Test: ✅ Working")
                return True
            else:
                print(f"   API Test: ❌ Failed ({test_response.status_code})")
                return False
        else:
            print(f"❌ {name}: Health check failed ({health_response.status_code})")
            return False
            
    except requests.exceptions.RequestException as e:
        print(f"❌ {name}: Connection failed - {e}")
        return False

def main():
    """Monitor all deployments"""
    print(f"\n🔍 Monitoring QR API Deployments - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 60)
    
    all_healthy = True
    
    for name, url in DEPLOYMENTS.items():
        is_healthy = check_deployment(name, url)
        if not is_healthy:
            all_healthy = False
    
    print("=" * 60)
    if all_healthy:
        print("🎉 All deployments are healthy!")
    else:
        print("⚠️  Some deployments have issues")
    
    return all_healthy

if __name__ == "__main__":
    main()